const url = `http://localhost:8000/api/countries`;

// ------------- Zadanie 14.15 -------------

// console.log('Przed 14.15')

// function getRandomInt(max) {
//     return Math.floor(Math.random() * max);
// }

// function checkIfEven(id) {
//     return new Promise((resolve, reject) => {
//         if (id % 2 == 0) {
//             resolve('Jest parzysty!');
//         } else {
//             reject('Nie jest parzysty!');
//         }
//     });
// }

// const id = getRandomInt(20);
// console.log(id);

// checkIfEven(id)
//     .then(data => console.log(data))
//     .catch(error => console.log(error))
//     .finally(() => console.log('Koniec1'));

// // lub
// checkIfEven(id).then(
//     data => console.log(data),
//     error => console.log(error)
// ).finally(() => console.log('Koniec2'));

// // lub
// async function funkcja(){
//     try {
//         const data = await checkIfEven(id);
//         console.log(data);
//     } catch (error) {
//         console.log(error);
//     } finally {
//         console.log('Koniec3');
//     }
// }

// funkcja();

// console.log('Po 14.15')

// ------------- Zadanie 14.16 -------------

// console.log('Przed 14.16')

// fetch(url)
//     .then(response => response.json())
//     .then(data => console.log(data))

// console.log('Po 14.16')

// ------------- Zadanie 14.17 -------------

// const id = 1;

// Wykonanie zadania

// ------------- Zadanie 14.18 -------------

// const slowacja = {
//     name: "Słowacja",
//     code: "SK",
//     currency: "euro",
//     area: 49035,
//     language: "słowacki"
// };

// Wykonanie zadania

// ------------- Zadanie 14.19 -------------

// const id = 6;

// const australia = {
//     name: "Australia",
//     code: "AU",
//     currency: "dolar australijski",
//     area: 7686850,
//     language: "angielski"
// };

// Wykonanie zadania

// ------------- Zadanie 14.20 -------------

// const id = 8;

// Wykonanie zadania
