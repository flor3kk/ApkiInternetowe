const url = `http://localhost:8000/api/countries`;

// ------------- Zadanie 14.8 -------------

// console.log('Przed 14.8')
// const xhr = new XMLHttpRequest();
// xhr.open('GET', url, false);
// xhr.send();
// if (xhr.status === 200) {
//     console.log(xhr.responseText);
// }
// console.log('Po 14.8')

// ------------- Zadanie 14.9 -------------

// console.log('Przed 14.9')
// const xhr = new XMLHttpRequest();
// xhr.open('GET', url);
// xhr.responseType = 'json';
// xhr.send(null);
// xhr.onreadystatechange = function () {
//     if (this.readyState == 0) {
//         console.log("UNSET");
//     }
//     if (this.readyState == 1) {
//         console.log("OPEN");
//     }
//     if (this.readyState == 2) {
//         console.log("HEADERS_RECEIVED");
//     }
//     if (this.readyState == 3) {
//         console.log("LOADING");
//     }
//     if (this.readyState == 4 && this.status == 200) {
//         console.log("DONE");
//         console.log(xhr.response);
//     }
// }
// console.log('Po 14.9')

// ------------- Zadanie 14.10 -------------

// const id = 11;

// Wykonanie zadania

// ------------- Zadanie 14.11 -------------

// const czechy = {
//     name: "Czechy",
//     code: "CZ",
//     currency: "korona",
//     area: 78868,
//     language: "czeski"
// };

// Wykonanie zadania

// ------------- Zadanie 14.12 -------------

// const id = 6;

// const australia = {
//     name: "Australia",
//     code: "AU",
//     currency: "dolar australijski",
//     area: 7686850,
//     language: "angielski"
// };

// Wykonanie zadania

// ------------- Zadanie 14.13 -------------

// const id = 11;

// Wykonanie zadania
