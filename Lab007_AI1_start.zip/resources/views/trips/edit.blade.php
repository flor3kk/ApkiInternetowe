@include('shared.html')

@include('shared.head', ['pageTitle' => 'Edytuj dane wycieczki'])

<body>
    @include('shared.navbar')



    @include('shared.footer')
</body>

</html>
