<?php
//Zad 2.10
