<?php
//Zad 2.4
$text1 = "   Programuję dobrze  ";
$text2 = "dobrze w PHP.  ";
