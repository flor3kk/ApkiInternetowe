<?php
//Zad 2.6
