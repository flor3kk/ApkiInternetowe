<?php
//Zad 2.12

require_once __DIR__ . "/vendor/autoload.php";
use Ramsey\Uuid\Uuid;

class Dog
{

}
