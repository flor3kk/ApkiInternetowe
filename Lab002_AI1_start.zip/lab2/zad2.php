<?php
//Zad 2.2
