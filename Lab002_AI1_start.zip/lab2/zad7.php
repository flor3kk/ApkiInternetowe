<?php
//Zad 2.7
$l = 10;
