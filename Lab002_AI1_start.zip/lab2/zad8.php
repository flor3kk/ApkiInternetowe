<?php
//Zad 2.8

