<?php
//Zad 2.13

class Point
{
    public function __construct(private float $x, private float $y)
    {

    }

}

