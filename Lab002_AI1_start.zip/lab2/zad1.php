<?php
//Zad 2.1
