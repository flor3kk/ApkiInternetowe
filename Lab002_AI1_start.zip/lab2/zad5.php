<?php
//Zad 2.5

$n = 3.5;
$note;
