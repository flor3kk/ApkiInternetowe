<?php

namespace App\Services;

class TripService
{
    public function calculatePromoPrice($price)
    {

    }

}
